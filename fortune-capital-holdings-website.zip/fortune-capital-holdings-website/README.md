# Fortune Capital Holdings Website

This is the official website for **Fortune Capital Holdings (Pty) Ltd**, a private investment firm based in Cape Town. The company specializes in acquiring logistics businesses through creative deal structuring.

## Features
- Clean, professional single-page design
- Blue and white color scheme
- Mobile-friendly layout

## How to Use
Simply open `index.html` in your browser.
